import mvnmm
# import expreg