import pylineaGT.mvnmm
# import pylineaGT.expreg